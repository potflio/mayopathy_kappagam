<?php 
require("class_hospital.php");
// echo$_SERVER["REQUEST_METHOD"] ;
echo$_POST['insert'];
$obj = new Hospital();
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // if ($_POST['insert'] == "insert") {
        $data = [
            "Consultation_No" => $_POST['Consultation_No'],
            "Patient_Name" => $_POST['Patient_Name'],
            "Upload_Image" => $_POST['Upload_Image'],
            "Father_Name" => $_POST['Father_Name'],
            "Patient_Date_of_Birth" => $_POST['Patient_Date_of_Birth'],
            "Patient_Age" => $_POST['Patient_Age'],
            "Communication_Address" => $_POST['Communication_Address'],
            "Mobile_Number" => $_POST['Mobile_Number'],
            "Alternative_Number" => $_POST['Alternative_Number'],
            "Email_ID" => $_POST['Email_ID'],
            "Aadhar_Number" => $_POST['Aadhar_Number'],
            "Smart_Card_Number" => $_POST['Smart_Card_Number'],
            "Disability_Card_Number" => $_POST['Disability_Card_Number'],
            "UDID_Card_Number" => $_POST['UDID_Card_Number'],
            "Physiotherapist_Name" => $_POST['Physiotherapist_Name'],
            "Trainer_Name" => $_POST['Trainer_Name'],
            "Kattu_Person_Name" => $_POST['Kattu_Person_Name'],
            "Admission_No" => $_POST['Admission_No'],
            "Consultation_Date" => $_POST['Consultation_Date'],
            "Reference" => $_POST['Reference'],
            "Diagnosis"=> $_POST['Diagnosis'],
            "Machine_Size" => $_POST['Machine_Size'],
            "Chest_Belt_Size" => $_POST['Chest_Belt_Size'],
            "LS_Belt_Size" => $_POST['LS_Belt_Size'],
            "Monthly_Fees" => $_POST['Monthly_Fees'],
            "Fees" => $_POST['Fees'],
            "Machine" => $_POST['Machine'],
            "Belt" => $_POST['Belt'],
            "File_Amount" => $_POST['File_Amount'],
            "Paid_Amount" => $_POST['Paid_Amount'],
            "Mode_of_Payment" => $_POST['Mode_of_Payment'],
        ];
    //   echo$data;
      
        // echo $obj->insert("patient",$data);
        if($obj->insert("patient",$data)==TRUE){
            echo "Data inserted successfully!";
        } else {
            echo "Failed to insert data.";
        }
    // }
    
}  //post close

$users = $obj->full_display("patient");
foreach($users as $user){
  
    echo $user['Patient_Name']."<br>"; 
}


$patient_count = $obj->single_display("select count(Patient_Name)as PNAME from patient where Patient_Name='8'");
echo"COUNT:".$patient_count['PNAME'];
 
$obj->closeconnect();
?>
