<!DOCTYPE html>
<?php 
require("class_hospital.php");
$obj=new Hospital();
$consultant=$obj->full_display("consultant");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultation Details</title>
   <?php include 'navbar.php'; ?>
    <style>
        .add-button {
            background: linear-gradient(to right, #a18cd1, #fbc2eb);
            border: none;
            color: white;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 20px;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
        }
        .add-button:hover {
            background: linear-gradient(to right, #fbc2eb, #a18cd1);
        }
        .table-icons {
            font-size: 1.2rem;
        }
    </style>
</head>
<body>
    <div class="container my-5">
    <h1 class="text-center text-primary">Consultation Details</h1>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1></h1>
            <a href="consultation_form.php" class="add-button">+ ADD</a>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-primary text-center">
                    <tr>
                        <th>S.No</th>
                        <th>Admission No</th>
                        <th>Patient Name</th>
                        <th>Mobile Number</th>
                        <th>Consultation Fee (₹)</th>
                        <th>Profile</th>
                        <th>Payment</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                foreach($consultant as $consultant){
                  ?>  
                    <tr>
                    <td><?php echo $consultant['Admission_No']; ?></td>
                    <td><?php echo $consultant['Patient_Name']; ?></td>
                    <td><?php echo $consultant['Mobile_Number']; ?></td>
                    <td><?php echo $consultant['Consultation_Fee']; ?></td>
                        <td class="text-center"><a href="consultator_profile.php"><span class="table-icons">👤</span></a></td>
                        <td class="text-center"><a href="patient_payment_voucher.php"><span class="table-icons">💲</span></a></td>
                        <td>Paid</td>
                    </tr>
                    <?php } ?>
                    
                </tbody>
            </table>
        </div>
    </div>

    
</body>
</html>
