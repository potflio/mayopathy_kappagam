<?php 
require("class_hospital.php");
// echo$_SERVER["REQUEST_METHOD"] ;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $obj = new Hospital();
     //if ($_POST['insert'] == "insert") {
        $data = [
            
           
            "Name"=>$_POST['Name'],
            "Designation"=>$_POST['Designation'],
            "Age"=>$_POST['Age'],
            "Address"=>$_POST['Address'],
            "Sex"=>$_POST['Sex'],
            "Reference"=>$_POST['Reference'],
            "Qualification"=>$_POST['Qualification'],
 
        ];
        if($obj->insert("staff",$data)==TRUE){
            echo "Data inserted successfully!";
        } else {
            echo "Failed to insert data.";
        }
    // }
    
}
$obj->closeconnect();
?>
