
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.2/css/boxicons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Header -->
    <header class="d-flex justify-content-between align-items-center p-3 bg-light border-bottom shadow">
        <div>
            <button class="btn btn-light" data-bs-toggle="offcanvas" data-bs-target="#nav-bar">
                <i class="bx bx-menu"></i>
            </button>
        </div>
        <div>
        <header class="d-flex align-items-center p-3 bg-light border-bottom shadow">
    <div class="me-3">
        <img src="assets/images/fav.png" alt="Logo" style="height: 50px;">
    </div>
    <div>
        <h4 class="text-center m-0">
            <span class="text-primary">MAYOPATHY</span> <span class="text-success">KAPPAGAM</span>
        </h4>
        <p class="h6 m-0">Institute of Cerebral Palsy & Muscular Dystrophy Center</p>
    </div>
</header>

        </div>
        <div></div> <!-- Empty div to balance the layout -->
    </header>

    <!-- Sidebar -->
    <div class="offcanvas offcanvas-start bg-primary text-white" tabindex="-1" id="nav-bar">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">Menu</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <nav class="nav flex-column">
                <a href="main_dashboard.php" class="nav-link text-white mb-2">
                    <i class="bx bx-home"></i>
                    <span class="ms-2">Dashboard</span>
                </a>
                <a href="consultation_details.php" class="nav-link text-white mb-2">
                    <i class="bx bx-user"></i>
                    <span class="ms-2">Consultation</span>
                </a>
                <a href="patient_details.php" class="nav-link text-white mb-2">
                    <i class="bx bx-user"></i>
                    <span class="ms-2">Patient's</span>
                </a>
                <a href="vendor_details.php" class="nav-link text-white mb-2">
                    <i class="bx bx-building"></i>
                    <span class="ms-2">Vendors</span>
                </a>
                <a href="#" class="nav-link text-white mb-2">
                    <i class="bx bx-bed"></i>
                    <span class="ms-2">Rooms</span>
                </a>
                <a href="staff_details.php" class="nav-link text-white mb-2">
                    <i class="bx bx-group"></i>
                    <span class="ms-2">Staff's</span>
                </a>
                <a href="expense.php" class="nav-link text-white mb-2">
                    <i class="bx bx-dollar"></i>
                    <span class="ms-2">Expense</span>
                </a>
                <a href="fee.php" class="nav-link text-white mb-2">
                    <i class="bx bx-money"></i>
                    <span class="ms-2">Fee</span>
                </a>
                <a href="reminder.php" class="nav-link text-white mb-2">
                    <i class="bx bx-bell"></i>
                    <span class="ms-2">Reminder's</span>
                </a>
                <a href="daybook.php" class="nav-link text-white mb-2">
                    <i class="bx bx-book"></i>
                    <span class="ms-2">DayBook</span>
                </a>
                <a href="balance_sheet.php" class="nav-link text-white">
                    <i class="bx bx-bar-chart-alt-2"></i>
                    <span class="ms-2">Balance Sheet</span>
                </a>
            </nav>
        </div>
    </div>