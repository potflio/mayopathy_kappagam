<!DOCTYPE html>
<html lang="en">
<?php 
require("class_hospital.php");
$obj=new Hospital();
$vendor=$obj->full_display("vendor");
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mayopathy Kappagam - Patient Details</title>

</head>

<body>
    <?php include 'navbar.php'; ?>
    <h2 class="text-center text-success mt-4">Patient Details</h2>
    <div class="text-end mb-3">
        <a href="vendor_add_form.php" class="btn btn-primary">+ADD NEW</a>
    </div>
    <div class="table-responsive">
        <table class="table table-striped table-hover align-middle text-center">
            <thead class="table-success">
                <tr>
                    <th scope="col">S.No</th>
                    <th scope="col">Bill Date</th>
                    <th scope="col">Vendor Name</th>
                    <th scope="col">Mobile Number</th>
                    <th scope="col">Bill Amount</th>
                    <th scope="col">Profile</th>
                    <th scope="col">Payment</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">1</th>
                    <td>05/01/2025</td>
                    <td>James</td>
                    <td>9845123670</td>
                    <td>54000</td>
                    <td>
                        <a href="vendor_profile.php">
                            <img class="img-fluid rounded-circle" style="max-width: 50px;" src="assets/icons/vendor_profile.png" alt="Profile">
                        </a>
                    </td>
                    <td>
                        <a href="vendor_payment.php">
                            <img class="img-fluid rounded-circle" style="max-width: 50px;" src="assets/icons/patient_payment.png" alt="Payment">
                        </a>
                    </td>
                    <td><span class="badge bg-success">Paid</span></td>
                </tr>
                <tr>
                    <th scope="row">2</th>
                    <td>05/01/2025</td>
                    <td>Kavin</td>
                    <td>9865471230</td>
                    <td>50000</td>
                    <td>
                        <a href="vendor_profile.php">
                            <img class="img-fluid rounded-circle" style="max-width: 50px;" src="assets/icons/vendor_profile.png" alt="Profile">
                        </a>
                    </td>
                    <td>
                        <a href="#">
                            <img class="img-fluid rounded-circle" style="max-width: 50px;" src="assets/icons/patient_payment.png" alt="Payment">
                        </a>
                    </td>
                    <td><span class="badge bg-warning">Pending</span></td>
                </tr>
            </tbody>
        </table>
    </div>


</body>

</html>