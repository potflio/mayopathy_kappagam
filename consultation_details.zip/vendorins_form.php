<?php 
require("class_hospital.php");
// echo$_SERVER["REQUEST_METHOD"] ;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $obj = new Hospital();
     if ($_POST['insert'] == "insert") {
        $data = [
            "Vendor_Name"=>$_POST['Vendor_Name'],
 "Bill_No"=>$_POST['Bill_No'],
  "Bill_Date"=>$_POST['Bill_Date'],
 "Machine"=>$_POST['Machine'],
 "Quantity"=>$_POST['Quantity'],
 "Price"=>$_POST['Price'],
 "Upload_Image"=>$_POST['Upload_Image'],
        ];
        if($obj->insert("vendor",$data)==TRUE){
            echo "Data inserted successfully!";
        } else {
            echo "Failed to insert data.";
        }
     }
    
}
$obj->closeconnect();
?>
