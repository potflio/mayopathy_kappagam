<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Expense Table</title>
  <?php include 'navbar.php'; ?>
</head>
<body>
  <div class="container mt-5">
    <h2 class="text-center text-primary mb-4">Expense</h2>
    <table class="table table-bordered">
      <thead class="table-warning">
        <tr>
          <th scope="col">S.NO</th>
          <th scope="col">Pay</th>
          <th scope="col">Log</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td scope="row">1</td>
          <td>100000</td>
          <td>23/04/2024</td>
        </tr>
        <tr>
          <td scope="row">2</td>
          <td>290000</td>
          <td>04/06/2024</td>
        </tr>
        <tr>
          <td scope="row">3</td>
          <td>300000</td>
          <td>09/08/2024</td>
        </tr>
      </tbody>
    </table>
  </div>


</body>
</html>
