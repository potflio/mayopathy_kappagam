<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee Table</title>
   <?php include 'navbar.php'; ?>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Fee</h1>
        <div class="table-responsive">
            <table class="table table-bordered text-center">
                <thead class="table-light">
                    <tr>
                        <th>S.No</th>
                        <th>A/No</th>
                        <th>Patient Name</th>
                        <th>Disease</th>
                        <th>Fees</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Pay</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>01</td>
                        <td>Karthink</td>
                        <td>DMD</td>
                        <td>1000</td>
                        <td>1000</td>
                        <td class="text-success">Paid</td>
                        <td>
                            <button class="btn btn-warning rounded-circle">Pay</button>
                        </td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>02</td>
                        <td>Suba</td>
                        <td>BMD</td>
                        <td>4000</td>
                        <td>2500</td>
                        <td class="text-danger">Pending</td>
                        <td>
                            <button class="btn btn-warning rounded-circle">Pay</button>
                        </td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>03</td>
                        <td>Samir</td>
                        <td>IBM</td>
                        <td>3000</td>
                        <td>3000</td>
                        <td class="text-success">Paid</td>
                        <td>
                            <a href="patient_payment_voucher.php" class="btn btn-warning rounded-circle">Pay</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    
</body>
</html>
