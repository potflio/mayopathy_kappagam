<?php 
require("class_hospital.php");
// echo$_SERVER["REQUEST_METHOD"] ;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $obj = new Hospital();
     //if ($_POST['insert'] == "insert") {
        $data = [
            "Room_No"=>$_POST['Room_No'],
            "Person_Name"=>$_POST['Person_Name'],
            "Open_Date"=>$_POST['Open_Date'],
            "Discharge_Date"=>$_POST['Discharge_Date'],
            "Room_Type"=>$_POST['Room_Type'],
            "Comments"=>$_POST['Comments'],
            "Amount"=>$_POST['Amount'],
			"Booking_Status" => "Booked",
 
        ];
        if($obj->insert("room",$data)==TRUE){
            echo "Data inserted successfully!";
						header("Location: https://veerasoftwareproject.in/hospital/room_details.php");
        } else {
            echo "Failed to insert data.";
        }
    // }
    
}
$obj->closeconnect();
?>
