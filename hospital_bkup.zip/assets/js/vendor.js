document.addEventListener("DOMContentLoaded", () => {
    const confirmBtn = document.getElementById("confirmBtn");
    const machineInput = document.getElementById("machine");
    const quantityInput = document.getElementById("quantity");
    const priceInput = document.getElementById("price");
    const tableBody = document.getElementById("tableBody");
    const totalAmount = document.getElementById("totalAmount");
    let serialNumber = 1;
    let total = 0;

    confirmBtn.addEventListener("click", () => {
        const machine = machineInput.value.trim();
        const quantity = parseInt(quantityInput.value, 10);
        const price = parseFloat(priceInput.value);

        if (machine && !isNaN(quantity) && !isNaN(price)) {
            const totalRowPrice = quantity * price;
            total += totalRowPrice;

            // Add a new row to the table
            const row = `
                <tr>
                    <td>${serialNumber++}</td>
                    <td>${machine}</td>
                    <td>${quantity}</td>
                    <td>${price.toFixed(2)}</td>
                    <td>${totalRowPrice.toFixed(2)}</td>
                    <td><button class="btn btn-danger"><i class="bi bi-trash"></i></button></td>
                </tr>
            `;
            tableBody.insertAdjacentHTML("beforeend", row);
            totalAmount.textContent = total.toFixed(2);

            // Clear the inputs
            machineInput.value = "";
            quantityInput.value = "";
            priceInput.value = "";
        } else {
            alert("Please fill in all fields with valid data.");
        }
    });
});