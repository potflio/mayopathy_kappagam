<!DOCTYPE html>
<html lang="en">
<?php 
require("class_hospital.php");
$obj=new Hospital();
$room=$obj->full_display("room");
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include 'navbar.php'; ?>
</head>

<body>
    <div class="container">
        <h2 class="text-center text-success mt-4">Room Details</h2>
		 <?php
        // Check if payment_success query parameter is present
        if (isset($_GET['payment_success']) && $_GET['payment_success'] == 'true') {
            echo '<div id="paymentAlert" class="alert alert-success alert-dismissible fade-out show" role="alert">
                    <strong>Payment Successful!</strong> The payment was successfully processed.
                </div>';
        }
        ?>
        <div class="text-end mb-3">
            <a href="room_add_form.php" class="btn btn-primary">+ADD NEW</a>
        </div>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="col-4">
                <input type="text" id="search" class="form-control" placeholder="Search by name..." oninput="filterTable()">
            </div>
            <button class="btn btn-success" onclick="downloadExcel()">Download Excel</button>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle text-center">
                <thead class="table-success">
                    <tr>
                        <th scope="col">S.No</th>
                        <th scope="col">Room No</th>
                        <th scope="col">Person Name</th>
                        <th scope="col">Open Date</th>
                        <th scope="col">Discharge Date</th>
                        <th scope="col">Room Type</th>
                        <th scope="col">Amount</th>
						 <th scope="col">Pay</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
					 <?php 
                foreach($room as $room){
                  ?> 
					<tr>
					<td><?php echo$room['id']; ?></td>
					<td><?php echo$room['Room_No']; ?></td>
					<td><?php echo$room['Person_Name']; ?></td>
					<td><?php echo$room['Open_Date']; ?></td>
					<td><?php echo$room['Discharge_Date']; ?></td>
					<td><?php echo$room['Room_Type']; ?></td>
					<td><?php echo$room['Amount']; ?></td>
					<td><a href="staff_payment_voucher.php">
                   <img class="img-fluid rounded-circle" style="max-width: 50px;" src="assets/icons/patient_payment.png" alt="Payment"></a>
					</td>
						<td><button type="submit" style= "background-color:pink" id="button">Booked</button></td>
					</tr>
					<?php } ?>
                </tbody>
				
            </table>
        </div>

        <div class="d-flex justify-content-center mt-3">
            <nav aria-label="Page navigation example">
                <ul id="pagination" class="pagination">
                    <!-- Pagination will be dynamically generated -->
                </ul>
            </nav>
        </div>
    </div>
	<meta http-equiv="refresh" content="4;url=room_details.php">
</body>
<script src="assets/js/room_details.js"></script>
</html>