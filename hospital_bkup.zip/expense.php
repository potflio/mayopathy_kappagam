<!DOCTYPE html>
<?php 
require("class_hospital.php");
$obj=new Hospital();
$expense=$obj->full_display("expense");
?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Expense Table</title>
  <?php include 'navbar.php'; ?>
</head>

<body>
  <div class="container mt-5">
    <h2 class="text-center text-primary mb-4">Expense</h2>
    <a href="expense_form.php" class="btn btn-primary">+ADD</a><br><br><br>
    <table class="table table-bordered">
      <thead class="table-warning">
        <tr>
          <th scope="col">S.NO</th>
          <th scope="col">Date</th>
          <th scope="col">Expense Name</th>
          <th scope="col">Amount</th>
          <th scope="col">Pay Type</th>
        </tr>
      </thead>
      <tbody>
		  <?php 
                foreach($expense as $expense){
                  ?>  
       <tr>
		     <td><?php echo $expense['id']; ?></td>
                    <td><?php echo $expense['Date']; ?></td>
		    <td><?php echo $expense['Expense_Name']; ?></td>
		    <td><?php echo $expense['Amount']; ?></td>
		    <td><?php echo $expense['Pay_Type']; ?></td>
		  </tr>
		  <?php } ?>
      </tbody>
    </table>
  </div>


</body>

</html>