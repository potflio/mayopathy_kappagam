<!DOCTYPE html>
<?php 
require("class_hospital.php");
$obj=new Hospital();
$patients=$obj->join_table("patient");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee Table</title>
   <?php include 'navbar.php'; ?>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Fee</h1>
        <div class="table-responsive">
            <table class="table table-bordered text-center">
                <thead class="table-light">
                    <tr>
                        <th>S.No</th>
                        <th>Patient_Name</th>
                        <th>Disease</th>
                        <th>Fees</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Pay</th>
                    </tr>
                </thead>
                <tbody>
					<?php
                   foreach($patients as $patient){
					   ?>
					<tr>
					<td><?php echo $patient['id']; ?></td>
					<td><?php echo $patient['Patient_Name']; ?></td>
					<td><?php echo $patient['Diagnosis']; ?></td>
					<td><?php echo $patient['Fees']; ?></td>
					<td><?php echo $patient['Amount']; ?></td>
						 <td class="text-success">Paid</td>
                        <td>
                            <a href="patient_payment.php" class="btn btn-warning rounded-circle">Pay</a>
						</td>
					</tr>
					<?php } ?>
					
                </tbody>
            </table>
        </div>
    </div>

    
</body>
</html>
