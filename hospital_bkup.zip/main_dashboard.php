<!DOCTYPE html>
<?php
require("class_hospital.php");
$obj=new Hospital();
//$id=$_GET['id'];
$patient_count=$obj->single_display("SELECT COUNT(id) AS id FROM patient");
$consultant_count=$obj->single_display("SELECT COUNT(id) AS id FROM consultant");
$expense_sum=$obj->single_display("SELECT SUM(Amount) AS total_Amount FROM expense");
$vendor_sum=$obj->single_display("SELECT SUM(Amount) AS total_Amount FROM vendor_payment");
$vendor_count=$obj->single_display("SELECT count(Bill_No) AS vendor_count FROM vendor_info");
$room = $obj->single_display("SELECT count(DISTINCT(Room_No))as room from room where Booking_Status='Booked'");
$total_rooms = $obj->single_display("SELECT count(Room_No)as total_rooms from total_rooms");

$total=$expense_sum['total_Amount'] + $vendor_sum['total_Amount'];
?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User-Friendly Dashboard</title>
    <?php include 'navbar.php'; ?>
    <style>
        .header {
            background: linear-gradient(to right, #4a00e0, #8e2de2);
            color: white;
            padding: 20px;
            border-radius: 10px;
        }

        .header img {
            height: 80px;
        }

        .card {
            border: 2px solid #007bff;
            border-radius: 10px;
            text-align: center;
            padding: 20px;
            transition: transform 0.2s ease;
        }

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .card .bi {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: #007bff;
        }

        .dashboard-grid {
            gap: 20px;
        }

        .footer {
            background: #007bff;
            color: white;
            padding: 10px 0;
            text-align: center;
            border-radius: 10px;
        }
    </style>
</head>

<body class="bg-light">

    <!-- Header -->
    <header class="header d-flex align-items-center mb-5">
        <img src="assets/images/fav.png" alt="Logo" class="me-3">
        <div>
            <h4 class="m-0">Good Morning</h4>
            <h2 class="m-0">Dr. Ramasamy</h2>
        </div>
    </header>

    <!-- Dashboard Content -->
    <div class="container">
        <div class="row row-cols-1 row-cols-md-4 g-4">
            <!-- Card 1 -->
            <div class="col">
                <div class="card">
                    <i class="bi bi-person-lines-fill"></i>
                    <h5 class="mt-2">Consultation</h5>
                  <p class="m-0"><?php echo $consultant_count['id']; ?>
					
                </div>
            </div>
            <!-- Card 2 -->
            <div class="col">
                <div class="card">
                    <i class="bi bi-people-fill"></i>
                    <h5 class="mt-2">Total Patients</h5>
                  <p class="m-0"><?php echo $patient_count['id']; ?>
</p>
                </div>
            </div>
            <!-- Card 3 -->
            <div class="col">
                <div class="card">
                    <i class="bi bi-basket-fill"></i>
                    <h5 class="mt-2">Vendors</h5>
					 <p class="m-0"><?php echo $vendor_count['vendor_count']; ?>
                </div>
            </div>
            <!-- Card 4 -->
            <div class="col">
                <div class="card">
                    <i class="bi bi-building"></i>
                    <h5 class="mt-2">Total Rooms</h5>
					 <p class="m-0"><?php echo $room['room']; ?>/<?php echo $total_rooms['total_rooms']; ?>
                </div>
            </div>
            <!-- Card 5 -->
            <div class="col">
                <div class="card">
                    <i class="bi bi-person-workspace"></i>
                    <h5 class="mt-2">10 Total Staff</h5>
                </div>
            </div>
            <!-- Card 6 -->
            <div class="col">
                <div class="card">
                    <i class="bi bi-cash-coin"></i>
                    <h5 class="mt-2">35/40 Fees</h5>
                </div>
            </div>
            <!-- Card 7 -->
            <div class="col">
                <div class="card">
                    <i class="bi bi-coin"></i>
                    <h5 class="mt-2">Expense</h5>
					 <p class="m-0"><?php echo $total; ?>
                </div>
            </div>
            <!-- Card 8 -->
            <div class="col">
                <div class="card">
                    <i class="bi bi-bell-fill"></i>
                    <h5 class="mt-2">Reminders</h5>
                </div>
            </div>
            <!-- Card 9 -->
            <div class="col">
                <div class="card">
                    <i class="bi bi-book"></i>
                    <h5 class="mt-2">DayBook</h5>
                </div>
            </div>
            <!-- Card 10 -->
            <div class="col">
                <div class="card">
                    <i class="bi bi-journal"></i>
                    <h5 class="mt-2">Balance Sheet</h5>
                </div>
            </div>
        </div>
    </div>

    <!-- Reminder Table -->
    <div class="container mt-5">
        <h3 class="text-center mb-4">Reminder (Today)</h3>
        <div class="table-responsive">
            <table class="table table-bordered table-striped text-center">
                <thead class="table-primary">
                    <tr>
                        <th>S.No</th>
                        <th>Patient Name</th>
                        <th>Due Amount (₹)</th>
                        <th>Due Date</th>
                        <th>Payment Mode</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Mr. Ravi Kumar</td>
                        <td>15,000</td>
                        <td>27-Dec-2024</td>
                        <td>Online/UPI</td>
                        <td>Follow-up consultation</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Ms. Priya Sharma</td>
                        <td>8,500</td>
                        <td>28-Dec-2024</td>
                        <td>Cash/Card</td>
                        <td>Physiotherapy package</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Mr. Anil Verma</td>
                        <td>12,000</td>
                        <td>29-Dec-2024</td>
                        <td>Online/Net Banking</td>
                        <td>Diagnosis test fees</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-3">
            <nav>
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                </ul>
            </nav>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer mt-5">
        <p class="mb-0">© 2025 User-Friendly Dashboard | Designed by [Your Name]</p>
    </footer>

</body>

</html>
