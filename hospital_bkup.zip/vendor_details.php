<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mayopathy Kappagam - Patient Details</title>

</head>

<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <h2 class="text-center text-success mt-4">Vendor Details</h2>
		 <?php
        // Check if payment_success query parameter is present
        if (isset($_GET['payment_success']) && $_GET['payment_success'] == 'true') {
            echo '<div id="paymentAlert" class="alert alert-success alert-dismissible fade-out show" role="alert">
                    <strong>Payment Successful!</strong> The payment was successfully processed.
                </div>';
        }
        ?>
        <div class="text-end mb-3">
            <a href="vendor_add_form.php" class="btn btn-primary">+ADD NEW</a>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle text-center">
                <thead class="table-success">
                    <tr>
                        <th scope="col">S.No</th>
                        <th scope="col">Bill Date</th>
                        <th scope="col">Vendor Name</th>
                        <th scope="col">Mobile Number</th>
                        <th scope="col">Bill Amount</th>
                        <th scope="col">View</th>
                        <th scope="col">Payment</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td>05/01/2025</td>
                        <td>James</td>
                        <td>9845123670</td>
                        <td>54000</td>
                        <td>
                            <a href="vendor_view.php">
                                <img class="img-fluid rounded-circle" style="max-width: 50px;" src="assets/icons/vision.png" alt="Profile">
                            </a>
                        </td>
                        <td>
                            <a href="vendor_payment.php">
                                <img class="img-fluid rounded-circle" style="max-width: 50px;" src="assets/icons/patient_payment.png" alt="Payment">
                            </a>
                        </td>
                        <td><span class="badge bg-success">Paid</span></td>
                    </tr>
                    <tr>
                        <th scope="row">2</th>
                        <td>05/01/2025</td>
                        <td>Kavin</td>
                        <td>9865471230</td>
                        <td>50000</td>
                        <td>
                            <a href="vendor_view.php">
                                <img class="img-fluid rounded-circle" style="max-width: 50px;" src="assets/icons/vision.png" alt="Profile">
                            </a>
                        </td>
                        <td>
                            <a href="#">
                                <img class="img-fluid rounded-circle" style="max-width: 50px;" src="assets/icons/patient_payment.png" alt="Payment">
                            </a>
                        </td>
                        <td><span class="badge bg-warning">Pending</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
<meta http-equiv="refresh" content="4;url=vendor_details.php">

</body>

</html>