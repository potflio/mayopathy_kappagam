<!DOCTYPE html>
<html lang="en">
<?php 
require("class_hospital.php");
$obj=new Hospital();
$patient_payment=$obj->full_display("patient_payment");
$id=$_GET['id'];
$patient=$obj->single_display("SELECT * FROM patient WHERE id=$id");
?>
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Payment</title>
    <?php include 'navbar.php'; ?>
</head>

<body>

    <div class="container mt-5">
        <!-- Header Section -->
        <h1 class="h4 text-primary text-center">Patient Payment</h1>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <!-- Do not Erase It -->
            <h1></h1>
            <!-- Do not Erase It -->
            <span class="badge bg-success p-2 fs-5">Paid</span>
        </div>

        <!-- Patient Profile Section -->
        <div class="row mb-4">
            <div class="col-md-3 text-center">
                <img src="assets/icons/patient_profile.png" alt="Patient Profile" class="rounded-circle mb-2" style="max-width: 150px; height: auto;">
                <p class="fw-bold mb-0 text-primary">Patient Profile:</p>
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-6">
						<p><strong>Consultation No:</strong><?php echo $patient['Consultation_No']; ?></p>
                        <p><strong>Patient Name:</strong> <?php echo  $patient['Patient_Name']; ?></p>
                        <p><strong>Patient Age:</strong><?php echo  $patient['Patient_Age']; ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Communication Address:</strong> <?php echo $patient['Communication_Address']; ?></p>
                        <p><strong>Mobile Number:</strong> <?php echo  $patient['Mobile_Number']; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Payment Table -->
        <div class="table-responsive">
            <table class="table table-bordered text-center">
                <thead class="table-light">
                    <tr>
                        <th>S.No</th>
                        <th>Payment Date</th>
                        <th>Amount Paid (₹)</th>
                        <th>Payment Mode</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                foreach($patient_payment as $patient_payment){
                  ?>  
                    <tr>
                        <td><?php echo $patient_payment['id']; ?></td>
                        <td><?php echo $patient_payment['Date']; ?></td>
                        <td><?php echo $patient_payment['Amount']; ?></td>
						<td><?php echo $patient_payment['Payment_Mode']; ?></td>                    
                    </tr>
					<?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>