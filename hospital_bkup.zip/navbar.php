<!-- Bootstrap CDN -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<!-- Header -->
<header class="d-flex justify-content-between align-items-center p-3 bg-white border-bottom shadow-sm fixed-top">
    <!-- Sidebar Toggle Button -->
    <button class="btn btn-outline-primary" data-bs-toggle="offcanvas" data-bs-target="#nav-bar">
        <i class="bi bi-list"></i>
    </button>

    <!-- Logo and Title -->
    <div class="text-center w-100">
        <img src="assets/images/fav.png" alt="Logo" class="d-block mx-auto" style="height: 50px;">
        <h4 class="m-0">
            <span class="text-primary">MAYOPATHY</span> <span class="text-success">KAPPAGAM</span>
        </h4>
        <p class="h6 m-0 text-muted">Institute of Cerebral Palsy & Muscular Dystrophy Center</p>
    </div>

    <!-- Empty Placeholder to Balance Layout -->
    <div></div>
</header>
<br><br><br><br><br><br>

<!-- Sidebar -->
<div class="offcanvas offcanvas-start bg-white" tabindex="-1" id="nav-bar" style="width: 250px;">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">Menu</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <nav class="nav flex-column">
            <a href="main_dashboard.php" class="nav-link text-dark mb-2 d-flex align-items-center">
                <i class="bi bi-house d-none d-lg-inline"></i>
                <span class="ms-lg-2">Dashboard</span>
            </a>
            <a href="consultation_details.php" class="nav-link text-dark mb-2 d-flex align-items-center">
                <i class="bi bi-person d-none d-lg-inline"></i>
                <span class="ms-lg-2">Consultation</span>
            </a>
            <a href="patient_details.php" class="nav-link text-dark mb-2 d-flex align-items-center">
                <i class="bi bi-people d-none d-lg-inline"></i>
                <span class="ms-lg-2">Patient's</span>
            </a>
            <a href="vendor_details.php" class="nav-link text-dark mb-2 d-flex align-items-center">
                <i class="bi bi-building d-none d-lg-inline"></i>
                <span class="ms-lg-2">Vendors</span>
            </a>
            <a href="room_details.php" class="nav-link text-dark mb-2 d-flex align-items-center">
                <i class="bi bi-hospital d-none d-lg-inline"></i>
                <span class="ms-lg-2">Rooms</span>
            </a>
            <a href="staff_details.php" class="nav-link text-dark mb-2 d-flex align-items-center">
                <i class="bi bi-people-fill d-none d-lg-inline"></i>
                <span class="ms-lg-2">Staff's</span>
            </a>
            <a href="expense.php" class="nav-link text-dark mb-2 d-flex align-items-center">
                <i class="bi bi-cash d-none d-lg-inline"></i>
                <span class="ms-lg-2">Expense</span>
            </a>
            <a href="fee.php" class="nav-link text-dark mb-2 d-flex align-items-center">
                <i class="bi bi-wallet2 d-none d-lg-inline"></i>
                <span class="ms-lg-2">Receipt</span>
            </a>
            <a href="reminder.php" class="nav-link text-dark mb-2 d-flex align-items-center">
                <i class="bi bi-bell d-none d-lg-inline"></i>
                <span class="ms-lg-2">Reminder's</span>
            </a>
            <a href="daybook.php" class="nav-link text-dark mb-2 d-flex align-items-center">
                <i class="bi bi-book d-none d-lg-inline"></i>
                <span class="ms-lg-2">DayBook</span>
            </a>
            <a href="balance_sheet.php" class="nav-link text-dark d-flex align-items-center">
                <i class="bi bi-bar-chart d-none d-lg-inline"></i>
                <span class="ms-lg-2">Balance Sheet</span>
            </a>
        </nav>
    </div>
</div>
