<?php 
require("class_hospital.php");
// echo$_SERVER["REQUEST_METHOD"] ;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $obj = new Hospital();
     //if ($_POST['insert'] == "insert") {
        $data = [
            "Patient_Code"=>$_POST['Patient_Code'],
            "Name"=>$_POST['Name'],
            "Date"=>$_POST['Date'],
            "Payment_Mode"=>$_POST['Payment_Mode'],
            "Amount"=>$_POST['Amount'],
 
        ];
        if($obj->insert("patient_payment",$data)==TRUE){
            echo "Data inserted successfully!";
			header("Location: https://veerasoftwareproject.in/hospital/patient_details.php?payment_success=true");
        } else {
            echo "Failed to insert data.";
        }
    // }
    
}
$obj->closeconnect();
?>
